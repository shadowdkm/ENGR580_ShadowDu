#ifndef RTW_HEADER_drone_5DOF_observer_capi_h_
#define RTW_HEADER_drone_5DOF_observer_capi_h_
#include "drone_5DOF_observer.h"
extern void drone_5DOF_observer_InitializeDataMapInfo ( void ) ;
#endif
