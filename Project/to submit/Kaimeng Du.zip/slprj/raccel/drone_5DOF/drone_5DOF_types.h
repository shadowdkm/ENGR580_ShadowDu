#ifndef RTW_HEADER_drone_5DOF_types_h_
#define RTW_HEADER_drone_5DOF_types_h_
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
typedef struct P_ P ;
#endif
