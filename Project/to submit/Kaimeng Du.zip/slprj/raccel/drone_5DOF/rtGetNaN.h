#ifndef RTW_HEADER_rtGetNaN_h_
#define RTW_HEADER_rtGetNaN_h_
#include "rt_nonfinite.h"
#include "rtwtypes.h"
extern real_T rtGetNaN ( void ) ; extern real32_T rtGetNaNF ( void ) ;
#endif
